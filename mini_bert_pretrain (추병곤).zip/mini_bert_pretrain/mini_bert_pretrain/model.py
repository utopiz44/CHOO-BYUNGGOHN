# -*- coding: utf-8 -*-
"""4단계: mini BERT 모델 정의 (TF2 / Keras, ~1.1M 파라미터).

구현 포인트
  - Embedding = token + (학습형) position + segment  -> LayerNorm -> Dropout
    * BERT는 Transformer 원논문의 사인파 인코딩이 아닌 학습 가능한
      position embedding을 사용한다.
  - Encoder = post-LN Transformer block, FFN 활성함수는 GELU
    * GELU(x) = x * Φ(x), tanh 근사식 사용 (Hendrycks & Gimpel, 2016)
  - MLM head: dense(hidden)+GELU+LN 후 token embedding 행렬과 weight tying
    하여 출력 -> 파라미터 절약(vocab x hidden 행렬 재사용)
  - NSP head: [CLS] pooler(dense+tanh) -> dense(2)
"""

import math

import tensorflow as tf

from config import CFG


def gelu(x):
    """Hendrycks & Gimpel (2016)의 tanh 근사 GELU."""
    cdf = 0.5 * (1.0 + tf.tanh(math.sqrt(2.0 / math.pi) * (x + 0.044715 * tf.pow(x, 3))))
    return x * cdf


class BertEmbeddings(tf.keras.layers.Layer):
    def __init__(self, cfg: "CFG.__class__", **kw):
        super().__init__(**kw)
        init = tf.keras.initializers.TruncatedNormal(stddev=0.02)
        self.token_emb = tf.keras.layers.Embedding(cfg.vocab_size, cfg.hidden_size,
                                                   embeddings_initializer=init, name="token")
        self.pos_emb = tf.keras.layers.Embedding(cfg.max_seq_length, cfg.hidden_size,
                                                 embeddings_initializer=init, name="position")
        self.seg_emb = tf.keras.layers.Embedding(cfg.type_vocab_size, cfg.hidden_size,
                                                 embeddings_initializer=init, name="segment")
        self.norm = tf.keras.layers.LayerNormalization(epsilon=1e-12)
        self.drop = tf.keras.layers.Dropout(cfg.dropout_rate)

    def call(self, input_ids, segment_ids, training=False):
        seq_len = tf.shape(input_ids)[1]
        pos_ids = tf.range(seq_len)[tf.newaxis, :]
        x = self.token_emb(input_ids) + self.pos_emb(pos_ids) + self.seg_emb(segment_ids)
        return self.drop(self.norm(x), training=training)


class TransformerBlock(tf.keras.layers.Layer):
    """원본 BERT와 동일한 post-LN 구조."""

    def __init__(self, cfg, **kw):
        super().__init__(**kw)
        init = tf.keras.initializers.TruncatedNormal(stddev=0.02)
        self.attn = tf.keras.layers.MultiHeadAttention(
            num_heads=cfg.num_heads,
            key_dim=cfg.hidden_size // cfg.num_heads,
            dropout=cfg.dropout_rate, kernel_initializer=init)
        self.ffn_in = tf.keras.layers.Dense(cfg.intermediate_size,
                                            activation=gelu, kernel_initializer=init)
        self.ffn_out = tf.keras.layers.Dense(cfg.hidden_size, kernel_initializer=init)
        self.norm1 = tf.keras.layers.LayerNormalization(epsilon=1e-12)
        self.norm2 = tf.keras.layers.LayerNormalization(epsilon=1e-12)
        self.drop = tf.keras.layers.Dropout(cfg.dropout_rate)

    def call(self, x, attention_mask, training=False):
        a = self.attn(x, x, attention_mask=attention_mask, training=training)
        x = self.norm1(x + self.drop(a, training=training))
        f = self.ffn_out(self.ffn_in(x))
        return self.norm2(x + self.drop(f, training=training))


class MiniBertForPretraining(tf.keras.Model):
    def __init__(self, cfg, **kw):
        super().__init__(**kw)
        self.cfg = cfg
        init = tf.keras.initializers.TruncatedNormal(stddev=0.02)

        self.embeddings = BertEmbeddings(cfg, name="embeddings")
        self.blocks = [TransformerBlock(cfg, name=f"layer_{i}")
                       for i in range(cfg.num_layers)]

        # NSP: [CLS] pooling
        self.pooler = tf.keras.layers.Dense(cfg.hidden_size, activation="tanh",
                                            kernel_initializer=init, name="pooler")
        self.nsp_head = tf.keras.layers.Dense(2, kernel_initializer=init, name="nsp")

        # MLM: transform 후 embedding 행렬과 weight tying
        self.mlm_dense = tf.keras.layers.Dense(cfg.hidden_size, activation=gelu,
                                               kernel_initializer=init, name="mlm_transform")
        self.mlm_norm = tf.keras.layers.LayerNormalization(epsilon=1e-12)
        self.mlm_bias = self.add_weight(name="mlm_output_bias",
                                        shape=(cfg.vocab_size,),
                                        initializer="zeros", trainable=True)

    def call(self, inputs, training=False):
        input_ids = inputs["input_ids"]
        input_mask = inputs["input_mask"]
        segment_ids = inputs["segment_ids"]
        mlm_positions = inputs["masked_lm_positions"]

        # (B, 1, 1, L) 형태 대신 keras MHA는 (B, Lq, Lk) 불리언 마스크 사용
        attn_mask = tf.cast(input_mask[:, tf.newaxis, :], tf.bool)
        attn_mask = tf.repeat(attn_mask, tf.shape(input_ids)[1], axis=1)

        x = self.embeddings(input_ids, segment_ids, training=training)
        for blk in self.blocks:
            x = blk(x, attn_mask, training=training)

        # ----- NSP logits -----
        pooled = self.pooler(x[:, 0])                 # [CLS]
        nsp_logits = self.nsp_head(pooled)            # (B, 2)

        # ----- MLM logits (마스크 위치만 gather하여 계산 절약) -----
        gathered = tf.gather(x, mlm_positions, batch_dims=1)   # (B, P, H)
        h = self.mlm_norm(self.mlm_dense(gathered))
        emb_matrix = self.embeddings.token_emb.embeddings      # (V, H) - weight tying
        mlm_logits = tf.matmul(h, emb_matrix, transpose_b=True) + self.mlm_bias

        return mlm_logits, nsp_logits


def count_params(model) -> int:
    return int(sum(tf.size(w).numpy() for w in model.trainable_weights))


if __name__ == "__main__":
    m = MiniBertForPretraining(CFG)
    dummy = {
        "input_ids": tf.zeros((2, CFG.max_seq_length), tf.int32),
        "input_mask": tf.ones((2, CFG.max_seq_length), tf.int32),
        "segment_ids": tf.zeros((2, CFG.max_seq_length), tf.int32),
        "masked_lm_positions": tf.zeros((2, CFG.max_predictions_per_seq), tf.int32),
    }
    m(dummy)
    print(f"[model] trainable params = {count_params(m):,}")
