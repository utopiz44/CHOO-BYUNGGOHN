# -*- coding: utf-8 -*-
"""3단계: MLM + NSP 사전학습 데이터셋 생성 (TFRecord).

원 논문(Devlin et al., 2019)의 create_pretraining_data 로직을 따른다.

NSP (Next Sentence Prediction)
  - 문서 내 문장들을 이어 붙여 target 길이에 가까운 A/B 세그먼트를 만든다.
  - 50% 확률로 B를 "같은 문서의 실제 다음 문장들"(IsNext, label=0),
    50% 확률로 "무작위 다른 문서의 문장들"(NotNext, label=1)로 구성한다.
  - 입력 형태: [CLS] A [SEP] B [SEP], segment_ids = 0...0 1...1

MLM (Masked Language Modeling)
  - 특수 토큰을 제외한 토큰 중 15%를 예측 대상으로 선택하고,
      80% -> [MASK] 치환
      10% -> 무작위 토큰 치환
      10% -> 원본 유지
  - dupe_factor 회 반복 생성하여 같은 문장에 서로 다른 마스크가 적용되게 한다(static masking).

사용:  python build_pretrain_data.py --input data/clean_corpus.txt \
          --sp_model tokenizer/ko_sp.model --output data/pretrain.tfrecord
"""

import argparse
import os
import random

import sentencepiece as spm
import tensorflow as tf

from config import CFG


# ---------------------------------------------------------------- 유틸

def read_documents(path, sp):
    """빈 줄로 구분된 문서를 읽어 [문서][문장][token id] 구조로 반환."""
    docs, cur = [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                if cur:
                    docs.append(cur)
                    cur = []
                continue
            ids = sp.encode(line, out_type=int)
            if ids:
                cur.append(ids)
    if cur:
        docs.append(cur)
    return [d for d in docs if len(d) >= 2]


def truncate_pair(tokens_a, tokens_b, max_num_tokens, rng):
    """A+B 길이가 초과하면 긴 쪽에서 앞/뒤 무작위로 제거."""
    while len(tokens_a) + len(tokens_b) > max_num_tokens:
        trunc = tokens_a if len(tokens_a) > len(tokens_b) else tokens_b
        if rng.random() < 0.5:
            trunc.pop(0)
        else:
            trunc.pop()


def apply_masking(tokens, rng, vocab_size):
    """MLM 마스킹. (masked tokens, positions, labels) 반환."""
    cand = [i for i, t in enumerate(tokens) if t not in (CFG.cls_id, CFG.sep_id)]
    rng.shuffle(cand)
    num_to_predict = min(CFG.max_predictions_per_seq,
                         max(1, int(round(len(tokens) * CFG.masked_lm_prob))))

    out = list(tokens)
    picked = sorted(cand[:num_to_predict])
    positions, labels = [], []
    for pos in picked:
        labels.append(tokens[pos])
        positions.append(pos)
        p = rng.random()
        if p < 0.8:                                   # 80% -> [MASK]
            out[pos] = CFG.mask_id
        elif p < 0.9:                                 # 10% -> 무작위 토큰
            out[pos] = rng.randint(5, vocab_size - 1)  # 특수토큰(0~4) 제외
        # else: 10% -> 원본 유지
    return out, positions, labels


# ------------------------------------------------- 문서 -> 학습 인스턴스

def create_instances_from_document(docs, doc_idx, rng, vocab_size):
    """원 논문 로직: 문장을 chunk로 모으다가 target 길이에 도달하면
    A/B로 분할하고 NSP 정/부정 쌍을 구성한다."""
    document = docs[doc_idx]
    max_num_tokens = CFG.max_seq_length - 3           # [CLS], [SEP], [SEP]
    target_len = max_num_tokens
    if rng.random() < CFG.short_seq_prob:
        target_len = rng.randint(2, max_num_tokens)

    instances, chunk, chunk_len = [], [], 0
    i = 0
    while i < len(document):
        chunk.append(document[i])
        chunk_len += len(document[i])
        last = (i == len(document) - 1)
        if last or chunk_len >= target_len:
            if chunk:
                a_end = rng.randint(1, len(chunk) - 1) if len(chunk) >= 2 else 1
                tokens_a = [t for s in chunk[:a_end] for t in s]

                # ----- NSP 쌍 구성 -----
                if len(chunk) == 1 or rng.random() < CFG.nsp_random_prob:
                    is_next = False                    # NotNext: 다른 문서에서 B 추출
                    tgt_b_len = target_len - len(tokens_a)
                    rand_doc_idx = doc_idx
                    while rand_doc_idx == doc_idx:
                        rand_doc_idx = rng.randint(0, len(docs) - 1)
                    rand_doc = docs[rand_doc_idx]
                    start = rng.randint(0, len(rand_doc) - 1)
                    tokens_b = []
                    for j in range(start, len(rand_doc)):
                        tokens_b.extend(rand_doc[j])
                        if len(tokens_b) >= tgt_b_len:
                            break
                    # 사용하지 않은 뒷문장은 되돌려 재사용
                    i -= len(chunk) - a_end
                else:
                    is_next = True                     # IsNext: 같은 문서의 다음 문장들
                    tokens_b = [t for s in chunk[a_end:] for t in s]

                truncate_pair(tokens_a, tokens_b, max_num_tokens, rng)
                if tokens_a and tokens_b:
                    tokens = [CFG.cls_id] + tokens_a + [CFG.sep_id] + tokens_b + [CFG.sep_id]
                    segment_ids = [0] * (len(tokens_a) + 2) + [1] * (len(tokens_b) + 1)
                    masked, positions, labels = apply_masking(tokens, rng, vocab_size)
                    instances.append(dict(
                        input_ids=masked, segment_ids=segment_ids,
                        masked_lm_positions=positions, masked_lm_ids=labels,
                        next_sentence_label=0 if is_next else 1,
                    ))
            chunk, chunk_len = [], 0
        i += 1
    return instances


# ----------------------------------------------------------- TFRecord

def _int_feat(values):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=list(values)))


def _float_feat(values):
    return tf.train.Feature(float_list=tf.train.FloatList(value=list(values)))


def instance_to_example(ins):
    L, P = CFG.max_seq_length, CFG.max_predictions_per_seq
    input_ids = ins["input_ids"][:L]
    input_mask = [1] * len(input_ids)
    segment_ids = ins["segment_ids"][:L]
    pad = L - len(input_ids)
    input_ids += [CFG.pad_id] * pad
    input_mask += [0] * pad
    segment_ids += [0] * pad

    pos = ins["masked_lm_positions"][:P]
    ids = ins["masked_lm_ids"][:P]
    w = [1.0] * len(pos)
    padp = P - len(pos)
    pos += [0] * padp
    ids += [0] * padp
    w += [0.0] * padp

    return tf.train.Example(features=tf.train.Features(feature={
        "input_ids": _int_feat(input_ids),
        "input_mask": _int_feat(input_mask),
        "segment_ids": _int_feat(segment_ids),
        "masked_lm_positions": _int_feat(pos),
        "masked_lm_ids": _int_feat(ids),
        "masked_lm_weights": _float_feat(w),
        "next_sentence_label": _int_feat([ins["next_sentence_label"]]),
    }))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=CFG.clean_corpus)
    ap.add_argument("--sp_model", default=CFG.sp_model_prefix + ".model")
    ap.add_argument("--output", default=CFG.tfrecord_path)
    ap.add_argument("--dupe_factor", type=int, default=CFG.dupe_factor)
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    rng = random.Random(CFG.random_seed)
    sp = spm.SentencePieceProcessor(model_file=args.sp_model)
    vocab_size = sp.get_piece_size()

    docs = read_documents(args.input, sp)
    print(f"[build_pretrain_data] documents={len(docs)}")
    assert len(docs) >= 2, "NSP 부정 예제 생성을 위해 문서가 2개 이상 필요합니다."

    n, n_isnext = 0, 0
    with tf.io.TFRecordWriter(args.output) as writer:
        for _ in range(args.dupe_factor):              # 반복마다 다른 마스크/분할
            order = list(range(len(docs)))
            rng.shuffle(order)
            for di in order:
                for ins in create_instances_from_document(docs, di, rng, vocab_size):
                    writer.write(instance_to_example(ins).SerializeToString())
                    n += 1
                    n_isnext += (ins["next_sentence_label"] == 0)

    print(f"[build_pretrain_data] instances={n}, "
          f"IsNext={n_isnext} ({n_isnext/max(n,1):.1%}), NotNext={n-n_isnext} "
          f"-> {args.output}")


if __name__ == "__main__":
    main()
