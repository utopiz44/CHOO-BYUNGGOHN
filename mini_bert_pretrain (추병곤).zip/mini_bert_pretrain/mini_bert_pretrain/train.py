# -*- coding: utf-8 -*-
"""5단계: mini BERT 사전학습.

  total_loss = MLM loss(마스크 위치 가중 평균) + NSP loss

안정적 학습을 위한 장치
  - linear warmup(초반 lr 점진 증가) + linear decay 스케줄
  - gradient clipping (clip_norm=1.0)
  - AdamW(weight decay는 LayerNorm/bias 제외)

step마다 MLM/NSP loss와 accuracy를 CSV에 기록하여 visualize.py 가
"loss의 안정적 감소"를 그래프로 증빙할 수 있게 한다.

사용:  python train.py --tfrecord data/pretrain.tfrecord --steps 20000
"""

import argparse
import csv
import os
import time

import tensorflow as tf

from config import CFG
from model import MiniBertForPretraining, count_params


# ------------------------------------------------------------ 입력

def make_dataset(tfrecord_path, batch_size):
    L, P = CFG.max_seq_length, CFG.max_predictions_per_seq
    feature_desc = {
        "input_ids": tf.io.FixedLenFeature([L], tf.int64),
        "input_mask": tf.io.FixedLenFeature([L], tf.int64),
        "segment_ids": tf.io.FixedLenFeature([L], tf.int64),
        "masked_lm_positions": tf.io.FixedLenFeature([P], tf.int64),
        "masked_lm_ids": tf.io.FixedLenFeature([P], tf.int64),
        "masked_lm_weights": tf.io.FixedLenFeature([P], tf.float32),
        "next_sentence_label": tf.io.FixedLenFeature([1], tf.int64),
    }

    def parse(rec):
        ex = tf.io.parse_single_example(rec, feature_desc)
        for k in ("input_ids", "input_mask", "segment_ids",
                  "masked_lm_positions", "masked_lm_ids", "next_sentence_label"):
            ex[k] = tf.cast(ex[k], tf.int32)
        return ex

    return (tf.data.TFRecordDataset(tfrecord_path)
            .map(parse, num_parallel_calls=tf.data.AUTOTUNE)
            .shuffle(CFG.shuffle_buffer)
            .repeat()                                  # step 기반 학습
            .batch(batch_size, drop_remainder=True)
            .prefetch(tf.data.AUTOTUNE))


# ------------------------------------------------------------ 스케줄

class WarmupLinearDecay(tf.keras.optimizers.schedules.LearningRateSchedule):
    def __init__(self, peak_lr, warmup_steps, total_steps):
        self.peak_lr = peak_lr
        self.warmup_steps = max(1, warmup_steps)
        self.total_steps = total_steps

    def __call__(self, step):
        step = tf.cast(step, tf.float32)
        warm = self.peak_lr * step / self.warmup_steps
        decay = self.peak_lr * tf.maximum(
            0.0, (self.total_steps - step) / max(1, self.total_steps - self.warmup_steps))
        return tf.where(step < self.warmup_steps, warm, decay)

    def get_config(self):
        return dict(peak_lr=self.peak_lr, warmup_steps=self.warmup_steps,
                    total_steps=self.total_steps)


# ------------------------------------------------------------ 손실

def compute_losses(model, batch, training):
    mlm_logits, nsp_logits = model(batch, training=training)

    # MLM: 패딩된 예측 슬롯은 weight=0으로 제외
    mlm_labels = batch["masked_lm_ids"]
    w = batch["masked_lm_weights"]
    per_tok = tf.keras.losses.sparse_categorical_crossentropy(
        mlm_labels, mlm_logits, from_logits=True)
    mlm_loss = tf.reduce_sum(per_tok * w) / (tf.reduce_sum(w) + 1e-6)

    mlm_pred = tf.argmax(mlm_logits, axis=-1, output_type=tf.int32)
    mlm_acc = tf.reduce_sum(
        tf.cast(tf.equal(mlm_pred, mlm_labels), tf.float32) * w) / (tf.reduce_sum(w) + 1e-6)

    # NSP
    nsp_labels = tf.squeeze(batch["next_sentence_label"], axis=-1)
    nsp_loss = tf.reduce_mean(tf.keras.losses.sparse_categorical_crossentropy(
        nsp_labels, nsp_logits, from_logits=True))
    nsp_pred = tf.argmax(nsp_logits, axis=-1, output_type=tf.int32)
    nsp_acc = tf.reduce_mean(tf.cast(tf.equal(nsp_pred, nsp_labels), tf.float32))

    return mlm_loss, nsp_loss, mlm_acc, nsp_acc


# ------------------------------------------------------------ 학습

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tfrecord", default=CFG.tfrecord_path)
    ap.add_argument("--steps", type=int, default=CFG.num_train_steps)
    ap.add_argument("--batch_size", type=int, default=CFG.batch_size)
    ap.add_argument("--warmup_steps", type=int, default=CFG.warmup_steps)
    ap.add_argument("--lr", type=float, default=CFG.learning_rate)
    ap.add_argument("--log_csv", default=CFG.log_csv)
    ap.add_argument("--ckpt_dir", default=CFG.ckpt_dir)
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.log_csv) or ".", exist_ok=True)
    os.makedirs(args.ckpt_dir, exist_ok=True)

    tf.keras.utils.set_random_seed(CFG.random_seed)

    ds = make_dataset(args.tfrecord, args.batch_size)
    model = MiniBertForPretraining(CFG)
    # 변수 생성(빌드)
    for batch in ds.take(1):
        model(batch, training=False)
    n_params = count_params(model)
    print(f"[train] trainable params = {n_params:,}  (target: ~1M)")

    schedule = WarmupLinearDecay(args.lr, args.warmup_steps, args.steps)
    optimizer = tf.keras.optimizers.AdamW(
        learning_rate=schedule, weight_decay=CFG.weight_decay,
        global_clipnorm=CFG.clip_norm)
    # BERT 관례: LayerNorm scale(gamma)/bias 는 weight decay 제외
    optimizer.exclude_from_weight_decay(
        var_names=["bias", "gamma", "beta", "norm"])

    ckpt = tf.train.Checkpoint(model=model, optimizer=optimizer)
    manager = tf.train.CheckpointManager(ckpt, args.ckpt_dir, max_to_keep=3)

    @tf.function
    def train_step(batch):
        with tf.GradientTape() as tape:
            mlm_loss, nsp_loss, mlm_acc, nsp_acc = compute_losses(model, batch, True)
            total = mlm_loss + nsp_loss
        grads = tape.gradient(total, model.trainable_variables)
        optimizer.apply_gradients(zip(grads, model.trainable_variables))
        return total, mlm_loss, nsp_loss, mlm_acc, nsp_acc

    with open(args.log_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["step", "total_loss", "mlm_loss", "nsp_loss",
                         "mlm_acc", "nsp_acc", "lr"])
        t0 = time.time()
        run = {"total": 0.0, "mlm": 0.0, "nsp": 0.0, "ma": 0.0, "na": 0.0, "n": 0}

        for step, batch in enumerate(ds.take(args.steps), start=1):
            total, mlm_l, nsp_l, mlm_a, nsp_a = train_step(batch)
            run["total"] += float(total); run["mlm"] += float(mlm_l)
            run["nsp"] += float(nsp_l);   run["ma"] += float(mlm_a)
            run["na"] += float(nsp_a);    run["n"] += 1

            if step % CFG.log_every == 0 or step == args.steps:
                n = run["n"]
                lr_now = float(schedule(tf.constant(step, tf.float32)))
                writer.writerow([step, run["total"]/n, run["mlm"]/n, run["nsp"]/n,
                                 run["ma"]/n, run["na"]/n, lr_now])
                f.flush()
                print(f"step {step:>6d}/{args.steps} | "
                      f"loss {run['total']/n:.4f} (mlm {run['mlm']/n:.4f}, "
                      f"nsp {run['nsp']/n:.4f}) | "
                      f"acc mlm {run['ma']/n:.3f}, nsp {run['na']/n:.3f} | "
                      f"lr {lr_now:.2e} | {(time.time()-t0):.0f}s")
                run = {k: 0.0 for k in run}; run["n"] = 0

            if step % CFG.ckpt_every == 0 or step == args.steps:
                manager.save(checkpoint_number=step)

    model.save_weights(os.path.join(args.ckpt_dir, "final.weights.h5"))
    print(f"[train] done. log -> {args.log_csv}, weights -> {args.ckpt_dir}")


if __name__ == "__main__":
    main()
