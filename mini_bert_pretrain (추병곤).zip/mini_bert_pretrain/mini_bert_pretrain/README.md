# Mini BERT (≈1M params) 한글 사전학습 파이프라인

한글 코퍼스 가공 → SentencePiece 토크나이저 → MLM+NSP 데이터셋(TFRecord)
→ mini BERT 학습 → 학습 곡선 시각화까지의 전체 파이프라인입니다.

## 실행 순서

```bash
pip install tensorflow sentencepiece matplotlib

# 1) 코퍼스 전처리 (한 줄 한 문장, 문서 사이 빈 줄 형식으로 변환)
python prepare_corpus.py --input data/raw_corpus.txt --output data/clean_corpus.txt

# 2) SentencePiece 토크나이저 학습 ([PAD]=0 [UNK]=1 [CLS]=2 [SEP]=3 [MASK]=4)
python train_tokenizer.py --input data/clean_corpus.txt --vocab_size 8000

# 3) MLM + NSP 사전학습 데이터셋 생성 (TFRecord)
python build_pretrain_data.py

# 4) 모델 파라미터 수 확인 (≈1.1M)
python model.py

# 5) 사전학습
python train.py --steps 20000

# 6) 시각화
python visualize.py
```

## 루브릭 대응

| 평가기준 | 대응 |
|---|---|
| MLM/NSP 특징이 반영된 데이터셋 생성 | `build_pretrain_data.py` — 15% 마스킹(80/10/10), IsNext/NotNext 50:50, `[CLS] A [SEP] B [SEP]` + segment id, dupe_factor로 static masking 다양화. 실행 로그에 IsNext 비율 출력 |
| 학습이 안정적으로 진행 | `train.py` — warmup+linear decay, gradient clipping, AdamW(LayerNorm/bias는 decay 제외). step별 MLM/NSP loss·acc CSV 기록 |
| 1M 규모 mini BERT | `model.py`·`config.py` — vocab 8000, hidden 96, layer 3, head 4, MLM 출력 weight tying. `python model.py`로 파라미터 수 출력 |
| 학습과정 시각화 | `visualize.py` — MLM loss / NSP loss / accuracy(NSP 0.5 기준선) / LR 4패널 PNG |

## 파라미터 예산 (≈1.13M)

| 구성 | 파라미터 |
|---|---|
| Token embedding (8000×96, MLM 출력과 공유) | 768,000 |
| Position(128×96) + Segment(2×96) + LN | ≈ 12,700 |
| Transformer block ×3 (attn + FFN 384) | ≈ 335,000 |
| Pooler + NSP + MLM transform/bias | ≈ 27,000 |

## 구현 근거

- **GELU**: FFN 활성함수로 `x·Φ(x)`의 tanh 근사식 사용 (Hendrycks & Gimpel, 2016)
- **학습형 position embedding**: BERT는 사인파 인코딩 대신 학습 가능한
  position embedding 사용
- **데이터 생성 로직**: Devlin et al. (2019)의 `create_pretraining_data.py` 절차
  (chunk 기반 A/B 분할, short_seq_prob, 무작위 truncation)를 따름
- 심화 확장 아이디어: ERNIE(Baidu, 2019)식 구/개체 단위 whole-span masking
