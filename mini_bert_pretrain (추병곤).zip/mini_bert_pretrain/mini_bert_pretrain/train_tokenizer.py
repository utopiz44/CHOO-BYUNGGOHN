# -*- coding: utf-8 -*-
"""2단계: SentencePiece 토크나이저 학습.

BERT의 특수 토큰 id를 다음과 같이 고정한다.
    [PAD]=0, [UNK]=1, [CLS]=2, [SEP]=3, [MASK]=4
SentencePiece에서 pad/unk는 예약 옵션으로, CLS/SEP/MASK는
user_defined_symbols(어휘 앞부분에 순서대로 삽입됨)로 확보한다.

사용:  python train_tokenizer.py --input data/clean_corpus.txt \
          --model_prefix tokenizer/ko_sp --vocab_size 8000
"""

import argparse
import os

import sentencepiece as spm

from config import CFG


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=CFG.clean_corpus)
    ap.add_argument("--model_prefix", default=CFG.sp_model_prefix)
    ap.add_argument("--vocab_size", type=int, default=CFG.vocab_size)
    ap.add_argument("--model_type", default=CFG.sp_model_type)
    ap.add_argument("--character_coverage", type=float, default=CFG.character_coverage)
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.model_prefix) or ".", exist_ok=True)

    spm.SentencePieceTrainer.train(
        input=args.input,
        model_prefix=args.model_prefix,
        vocab_size=args.vocab_size,
        model_type=args.model_type,
        character_coverage=args.character_coverage,
        pad_id=0, unk_id=1, bos_id=-1, eos_id=-1,          # bos/eos 미사용
        pad_piece="[PAD]", unk_piece="[UNK]",
        user_defined_symbols=["[CLS]", "[SEP]", "[MASK]"],  # id 2, 3, 4
        input_sentence_size=2_000_000,
        shuffle_input_sentence=True,
    )

    # 특수 토큰 id가 config와 일치하는지 검증
    sp = spm.SentencePieceProcessor(model_file=args.model_prefix + ".model")
    for piece, expected in [("[PAD]", 0), ("[UNK]", 1), ("[CLS]", 2), ("[SEP]", 3), ("[MASK]", 4)]:
        got = sp.piece_to_id(piece)
        assert got == expected, f"{piece} id mismatch: {got} != {expected}"

    demo = "버트 모델은 마스크 언어 모델링으로 사전학습된다."
    print(f"[train_tokenizer] vocab={sp.get_piece_size()}")
    print(f"  demo: {demo}")
    print(f"  ->   {sp.encode(demo, out_type=str)}")


if __name__ == "__main__":
    main()
