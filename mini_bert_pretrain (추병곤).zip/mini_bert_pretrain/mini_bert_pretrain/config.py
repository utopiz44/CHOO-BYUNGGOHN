# -*- coding: utf-8 -*-
"""전체 파이프라인 공통 설정.

mini BERT(~1M 파라미터) 사전학습을 위한 하이퍼파라미터를 한 곳에서 관리한다.
파라미터 수의 대부분은 token embedding(vocab_size x hidden_size)이 차지하므로,
1M 예산에 맞추기 위해 vocab=8000, hidden=96, layer=3 으로 설정했다.
(대략: embedding 0.77M + encoder 3층 0.33M + head ≈ 1.15M, MLM 출력은 embedding과 weight tying)
"""

from dataclasses import dataclass


@dataclass
class Config:
    # ---------- 경로 ----------
    raw_corpus: str = "data/raw_corpus.txt"        # 원본 한글 코퍼스(문서 구분: 빈 줄)
    clean_corpus: str = "data/clean_corpus.txt"    # 전처리 결과(한 줄 한 문장, 문서 사이 빈 줄)
    sp_model_prefix: str = "tokenizer/ko_sp"       # SentencePiece 모델 prefix
    tfrecord_path: str = "data/pretrain.tfrecord"  # MLM+NSP 학습 데이터
    ckpt_dir: str = "ckpt"                         # 체크포인트 저장 위치
    log_csv: str = "logs/train_log.csv"            # step별 loss/acc 로그
    plot_path: str = "logs/training_curves.png"    # 시각화 결과

    # ---------- 토크나이저 ----------
    vocab_size: int = 8000
    character_coverage: float = 0.9995             # 한국어 권장값
    sp_model_type: str = "unigram"

    # 특수 토큰 id (train_tokenizer.py 에서 이 순서로 고정됨)
    pad_id: int = 0
    unk_id: int = 1
    cls_id: int = 2
    sep_id: int = 3
    mask_id: int = 4

    # ---------- 사전학습 데이터 (MLM + NSP) ----------
    max_seq_length: int = 128
    max_predictions_per_seq: int = 20              # 128 * 0.15 ≈ 19.2
    masked_lm_prob: float = 0.15                   # 마스킹 대상 비율
    short_seq_prob: float = 0.10                   # 짧은 시퀀스 생성 비율(파인튜닝 강건성)
    dupe_factor: int = 5                           # 문서당 static masking 반복 횟수
    nsp_random_prob: float = 0.50                  # NotNext(다른 문서 문장) 비율
    random_seed: int = 42

    # ---------- 모델 (mini BERT, ~1.1M params) ----------
    hidden_size: int = 96
    num_layers: int = 3
    num_heads: int = 4                             # head dim = 24
    intermediate_size: int = 384                   # 4 * hidden
    dropout_rate: float = 0.1
    type_vocab_size: int = 2                       # segment A/B

    # ---------- 학습 ----------
    batch_size: int = 64
    num_train_steps: int = 20000
    warmup_steps: int = 1000
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    clip_norm: float = 1.0
    log_every: int = 50
    ckpt_every: int = 2000
    shuffle_buffer: int = 10000


CFG = Config()
