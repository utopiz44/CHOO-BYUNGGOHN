# -*- coding: utf-8 -*-
"""1단계: 한글 코퍼스 전처리.

입력  : 원본 텍스트 파일. 빈 줄로 문서가 구분되어 있다고 가정한다.
        (위키/뉴스 덤프처럼 문서 단위 구분이 없는 경우에도 그대로 사용 가능하며,
         이때 --paragraph_as_doc 옵션으로 문단을 문서로 취급할 수 있다.)
출력  : BERT pretrain 표준 포맷
        - 한 줄에 한 문장
        - 문서와 문서 사이는 빈 줄
        NSP에서 "같은 문서의 연속 문장"과 "다른 문서의 문장"을 구분해야 하므로
        문서 경계 보존이 필수적이다.

사용:  python prepare_corpus.py --input data/raw_corpus.txt --output data/clean_corpus.txt
"""

import argparse
import os
import re
import unicodedata

# 한국어 종결(다/요/죠/까/니 등) 뒤의 문장부호, 또는 일반 문장부호 기준의 단순 분리 규칙.
# 외부 형태소기 의존성을 없애기 위한 규칙 기반 분리이며, kss 등으로 교체 가능하다.
_SENT_SPLIT = re.compile(r"(?<=[.!?。！？])\s+")
_MULTI_SPACE = re.compile(r"\s+")
_KEEP = re.compile(r"[가-힣a-zA-Z0-9\s.,!?%~()\[\]'\"·:;/&+\-]")


def normalize_line(line: str) -> str:
    """유니코드 정규화 + 허용 문자 이외 제거 + 공백 정리."""
    line = unicodedata.normalize("NFKC", line)
    line = "".join(ch for ch in line if _KEEP.match(ch))
    return _MULTI_SPACE.sub(" ", line).strip()


def split_sentences(paragraph: str):
    for sent in _SENT_SPLIT.split(paragraph):
        sent = sent.strip()
        # 지나치게 짧은 조각(제목 잔여물 등)은 학습 신호가 약하므로 제거
        if len(sent) >= 5:
            yield sent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--paragraph_as_doc", action="store_true",
                    help="빈 줄 구분이 없는 코퍼스에서 각 줄(문단)을 하나의 문서로 취급")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)

    n_docs, n_sents = 0, 0
    with open(args.input, encoding="utf-8") as fin, \
         open(args.output, "w", encoding="utf-8") as fout:

        doc_buf = []

        def flush():
            nonlocal n_docs, n_sents
            sents = []
            for para in doc_buf:
                sents.extend(split_sentences(para))
            if len(sents) >= 2:            # NSP를 위해 최소 2문장 필요
                fout.write("\n".join(sents) + "\n\n")
                n_docs += 1
                n_sents += len(sents)
            doc_buf.clear()

        for raw in fin:
            line = normalize_line(raw)
            if not line:
                flush()
                continue
            doc_buf.append(line)
            if args.paragraph_as_doc:
                flush()
        flush()

    print(f"[prepare_corpus] documents={n_docs}, sentences={n_sents} -> {args.output}")


if __name__ == "__main__":
    main()
