# -*- coding: utf-8 -*-
"""6단계: 학습 로그 시각화.

train.py 가 남긴 CSV를 읽어 4개 패널을 그린다.
  (1) MLM loss   (2) NSP loss   (3) MLM/NSP accuracy   (4) learning rate
MLM/NSP loss가 각각 안정적으로 감소하는지, NSP acc가 무작위 기준선(0.5)을
넘어 상승하는지가 루브릭의 핵심 증빙이다.

사용:  python visualize.py --log_csv logs/train_log.csv --out logs/training_curves.png
"""

import argparse
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import CFG


def load_log(path):
    cols = {}
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            for k, v in row.items():
                cols.setdefault(k, []).append(float(v))
    return cols


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log_csv", default=CFG.log_csv)
    ap.add_argument("--out", default=CFG.plot_path)
    args = ap.parse_args()

    log = load_log(args.log_csv)
    steps = log["step"]

    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    fig.suptitle("Mini BERT Pretraining (MLM + NSP)", fontsize=14)

    ax = axes[0][0]
    ax.plot(steps, log["mlm_loss"], color="tab:blue")
    ax.set_title("MLM Loss"); ax.set_xlabel("step"); ax.set_ylabel("loss")
    ax.grid(alpha=0.3)

    ax = axes[0][1]
    ax.plot(steps, log["nsp_loss"], color="tab:orange")
    ax.set_title("NSP Loss"); ax.set_xlabel("step"); ax.set_ylabel("loss")
    ax.grid(alpha=0.3)

    ax = axes[1][0]
    ax.plot(steps, log["mlm_acc"], label="MLM acc", color="tab:blue")
    ax.plot(steps, log["nsp_acc"], label="NSP acc", color="tab:orange")
    ax.axhline(0.5, ls="--", lw=1, color="gray", label="NSP random baseline")
    ax.set_title("Accuracy"); ax.set_xlabel("step"); ax.set_ylim(0, 1)
    ax.legend(); ax.grid(alpha=0.3)

    ax = axes[1][1]
    ax.plot(steps, log["lr"], color="tab:green")
    ax.set_title("Learning Rate (warmup + linear decay)")
    ax.set_xlabel("step"); ax.grid(alpha=0.3)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    fig.savefig(args.out, dpi=150)
    print(f"[visualize] saved -> {args.out}")


if __name__ == "__main__":
    main()
