"""
평가/분석 (루브릭 ②③, 그리고 ①의 디코딩 비교).
학습 프레임워크와 무관 — 체크포인트 경로만 있으면 된다.

산출물:
  - comparison.csv  : 프롬프트별 (base / sft / ppo) 응답 + RM 점수
  - report.md       : 보고서에 붙일 정량 요약표 + 정성 샘플표
  - decoding.csv    : 동일 프롬프트에 대한 디코딩 전략별 SFT 응답 (루브릭 ①)

정량 지표:
  - ③ base KoGPT2 vs SFT : validation perplexity 비교
  - ② SFT vs RM(=PPO)    : RM 평균 점수 + win-rate (RM으로 채점한 승률)

사용 예:
    python evaluate.py --base skt/kogpt2-base-v2 --sft ./ckpt/sft \
        --ppo ./ckpt/ppo --rm ./ckpt/rm \
        --prompts data/eval_prompts.json --valtext data/val.json
"""
import argparse
import json
import math
import torch
import pandas as pd
from transformers import GPT2LMHeadModel, GPT2ForSequenceClassification
from utils import (load_tokenizer, load_lm, build_prompt, generate,
                   DECODING_VARIANTS)

DEVICE = "cuda"


@torch.no_grad()
def perplexity(model, tokenizer, texts, max_len=512):
    """causal LM perplexity (루브릭 ③ 정량 지표)."""
    nll, ntok = 0.0, 0
    for t in texts:
        ids = tokenizer(t, return_tensors="pt", truncation=True,
                        max_length=max_len).to(DEVICE)
        out = model(**ids, labels=ids["input_ids"])
        n = ids["input_ids"].numel()
        nll += out.loss.item() * n
        ntok += n
    return math.exp(nll / max(ntok, 1))


@torch.no_grad()
def rm_score(rm, tokenizer, prompt, response):
    text = build_prompt(prompt) + response
    enc = tokenizer(text, return_tensors="pt", truncation=True,
                    max_length=512).to(DEVICE)
    return rm(**enc).logits.squeeze(-1).item()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="skt/kogpt2-base-v2")
    ap.add_argument("--sft", required=True)
    ap.add_argument("--ppo", default=None)
    ap.add_argument("--rm", required=True)
    ap.add_argument("--prompts", required=True, help="평가 프롬프트 JSON [{'prompt':..}]")
    ap.add_argument("--valtext", default=None, help="perplexity용 텍스트 JSON [{'text':..}] 또는 completion 포함")
    ap.add_argument("--outdir", default=".")
    args = ap.parse_args()

    tok = load_tokenizer()
    base = load_lm(args.base, DEVICE); base.eval()
    sft = load_lm(args.sft, DEVICE); sft.eval()
    ppo = load_lm(args.ppo, DEVICE) if args.ppo else None
    if ppo: ppo.eval()
    rm = GPT2ForSequenceClassification.from_pretrained(args.rm, num_labels=1).to(DEVICE)
    rm.config.pad_token_id = tok.pad_token_id; rm.eval()

    with open(args.prompts, encoding="utf-8") as f:
        eval_prompts = [r["prompt"] for r in json.load(f)]

    # ── 응답 생성 + RM 채점 (②③ 정성/정량 공용 테이블) ────────────────
    rows = []
    for p in eval_prompts:
        b = generate(base, tok, p, DEVICE, do_sample=False)
        s = generate(sft, tok, p, DEVICE, do_sample=False)
        row = {"prompt": p, "base": b, "sft": s,
               "rm_base": rm_score(rm, tok, p, b),
               "rm_sft": rm_score(rm, tok, p, s)}
        if ppo:
            pp = generate(ppo, tok, p, DEVICE, do_sample=False)
            row["ppo"] = pp
            row["rm_ppo"] = rm_score(rm, tok, p, pp)
        rows.append(row)
    df = pd.DataFrame(rows)
    df.to_csv(f"{args.outdir}/comparison.csv", index=False, encoding="utf-8-sig")

    # ── 정량 요약 ────────────────────────────────────────────────────
    lines = ["# RLHF 결과 분석 리포트\n"]
    lines.append("## ② SFT vs RM(보상 관점)\n")
    lines.append(f"- 평균 RM 점수 — base: **{df.rm_base.mean():.3f}**, "
                 f"sft: **{df.rm_sft.mean():.3f}**"
                 + (f", ppo: **{df.rm_ppo.mean():.3f}**" if ppo else ""))
    lines.append(f"- SFT가 base보다 높은 비율(win-rate): "
                 f"**{(df.rm_sft > df.rm_base).mean()*100:.1f}%**")
    if ppo:
        lines.append(f"- PPO가 SFT보다 높은 비율(win-rate): "
                     f"**{(df.rm_ppo > df.rm_sft).mean()*100:.1f}%**")

    if args.valtext:
        with open(args.valtext, encoding="utf-8") as f:
            vt = json.load(f)
        texts = [v.get("text") or (build_prompt(v["prompt"]) + v["completion"]) for v in vt]
        ppl_base = perplexity(base, tok, texts)
        ppl_sft = perplexity(sft, tok, texts)
        lines.append("\n## ③ 기존 KoGPT2 vs SFT (perplexity, 낮을수록 좋음)\n")
        lines.append(f"- base: **{ppl_base:.2f}** → sft: **{ppl_sft:.2f}**")

    # ── 정성 샘플표 (앞 5개) ─────────────────────────────────────────
    lines.append("\n## 정성 비교 (샘플)\n")
    for _, r in df.head(5).iterrows():
        lines.append(f"**Q. {r['prompt']}**")
        lines.append(f"- base: {r['base']}")
        lines.append(f"- sft : {r['sft']}")
        if ppo:
            lines.append(f"- ppo : {r['ppo']}")
        lines.append("")
    with open(f"{args.outdir}/report.md", "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # ── 루브릭 ①: 디코딩 전략 비교 (SFT 모델 고정) ───────────────────
    drows = []
    for p in eval_prompts[:10]:
        row = {"prompt": p}
        for name, kw in DECODING_VARIANTS.items():
            row[name] = generate(sft, tok, p, DEVICE, **kw)
        drows.append(row)
    pd.DataFrame(drows).to_csv(f"{args.outdir}/decoding.csv",
                               index=False, encoding="utf-8-sig")

    print("완료: comparison.csv / report.md / decoding.csv 생성")
    print("\n".join(lines[:8]))


if __name__ == "__main__":
    main()
