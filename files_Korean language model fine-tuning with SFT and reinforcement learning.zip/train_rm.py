"""
2단계: Reward Model (RM)
같은 프롬프트에 대한 (chosen, rejected) 쌍을 받아, chosen에 더 높은 스칼라
점수를 주도록 학습. GPT2ForSequenceClassification(num_labels=1)을 스코어러로 사용.
pairwise ranking loss:  -log(sigmoid(r_chosen - r_rejected))

입력: JSON list [{"prompt":..., "chosen":..., "rejected":...}, ...]
출력: ./ckpt/rm/  (PPO의 reward, 평가의 스코어러로 사용)

사용 예:
    python train_rm.py --data data/rm_pairs.json --out ./ckpt/rm
"""
import argparse
import json
import torch
import torch.nn as nn
from datasets import Dataset
from transformers import (GPT2ForSequenceClassification, Trainer,
                          TrainingArguments)
from utils import load_tokenizer, build_prompt, BASE_MODEL

MAX_LEN = 512


def make_dataset(path, tokenizer):
    with open(path, encoding="utf-8") as f:
        rows = json.load(f)

    def enc(r):
        base = build_prompt(r["prompt"])
        ch = tokenizer(base + r["chosen"], truncation=True, max_length=MAX_LEN)
        rj = tokenizer(base + r["rejected"], truncation=True, max_length=MAX_LEN)
        return {
            "input_ids_chosen": ch["input_ids"],
            "attention_mask_chosen": ch["attention_mask"],
            "input_ids_rejected": rj["input_ids"],
            "attention_mask_rejected": rj["attention_mask"],
        }

    return Dataset.from_list([enc(r) for r in rows])


class RewardCollator:
    def __init__(self, tokenizer):
        self.tok = tokenizer

    def __call__(self, feats):
        def pad(key_ids, key_mask):
            batch = [{"input_ids": f[key_ids], "attention_mask": f[key_mask]} for f in feats]
            return self.tok.pad(batch, return_tensors="pt")
        ch = pad("input_ids_chosen", "attention_mask_chosen")
        rj = pad("input_ids_rejected", "attention_mask_rejected")
        return {"chosen": ch, "rejected": rj}


class RewardTrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        r_chosen = model(**inputs["chosen"]).logits.squeeze(-1)
        r_rejected = model(**inputs["rejected"]).logits.squeeze(-1)
        loss = -nn.functional.logsigmoid(r_chosen - r_rejected).mean()
        return (loss, {"r_chosen": r_chosen, "r_rejected": r_rejected}) if return_outputs else loss


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="./ckpt/rm")
    ap.add_argument("--epochs", type=int, default=1)
    ap.add_argument("--bs", type=int, default=2)
    ap.add_argument("--lr", type=float, default=1e-5)
    args = ap.parse_args()

    tokenizer = load_tokenizer()
    model = GPT2ForSequenceClassification.from_pretrained(BASE_MODEL, num_labels=1)
    model.config.pad_token_id = tokenizer.pad_token_id

    ds = make_dataset(args.data, tokenizer)
    targs = TrainingArguments(
        output_dir=args.out,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.bs,
        gradient_accumulation_steps=8,
        learning_rate=args.lr,
        fp16=True,
        logging_steps=20,
        save_strategy="epoch",
        report_to="none",
        remove_unused_columns=False,   # 커스텀 collator를 쓰므로 필수
    )
    trainer = RewardTrainer(model=model, args=targs, train_dataset=ds,
                            data_collator=RewardCollator(tokenizer))
    trainer.train()
    trainer.save_model(args.out)
    tokenizer.save_pretrained(args.out)
    print(f"[RM] 저장 완료 → {args.out}")


if __name__ == "__main__":
    main()
