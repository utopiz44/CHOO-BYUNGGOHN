"""
1단계: SFT (Supervised Fine-Tuning)
KoGPT2를 instruction 데이터로 지도학습. 표준 HuggingFace Trainer만 사용해
TRL 버전에 상관없이 동작하도록 했다.

입력: JSON list [{"prompt":..., "completion":...}, ...]  (prepare_data.py 출력)
출력: ./ckpt/sft/  (평가/PPO에서 이 경로를 actor로 사용)

사용 예:
    python train_sft.py --data data/sft_clean.json --out ./ckpt/sft
"""
import argparse
import json
from datasets import Dataset
from transformers import (GPT2LMHeadModel, Trainer, TrainingArguments,
                          DataCollatorForLanguageModeling)
from utils import load_tokenizer, build_prompt, BASE_MODEL

MAX_LEN = 512


def make_dataset(path, tokenizer):
    with open(path, encoding="utf-8") as f:
        rows = json.load(f)

    def to_text(r):
        # 프롬프트 + 정답 응답 + eos. 라벨은 전체(causal LM) — 프롬프트 부분
        # 손실을 마스킹하고 싶으면 여기서 labels를 -100으로 채우면 된다.
        return {"text": build_prompt(r["prompt"]) + r["completion"] + tokenizer.eos_token}

    ds = Dataset.from_list([to_text(r) for r in rows])

    def tok(batch):
        return tokenizer(batch["text"], truncation=True, max_length=MAX_LEN)

    return ds.map(tok, batched=True, remove_columns=["text"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", default="./ckpt/sft")
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=4)
    ap.add_argument("--lr", type=float, default=5e-5)
    args = ap.parse_args()

    tokenizer = load_tokenizer()
    model = GPT2LMHeadModel.from_pretrained(BASE_MODEL)
    model.config.pad_token_id = tokenizer.pad_token_id

    train_ds = make_dataset(args.data, tokenizer)
    collator = DataCollatorForLanguageModeling(tokenizer, mlm=False)

    targs = TrainingArguments(
        output_dir=args.out,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.bs,
        gradient_accumulation_steps=8,
        learning_rate=args.lr,
        warmup_ratio=0.03,
        weight_decay=0.01,
        fp16=True,
        logging_steps=20,
        save_strategy="epoch",
        report_to="none",
    )
    trainer = Trainer(model=model, args=targs,
                      train_dataset=train_ds, data_collator=collator)
    trainer.train()
    trainer.save_model(args.out)
    tokenizer.save_pretrained(args.out)
    print(f"[SFT] 저장 완료 → {args.out}")


if __name__ == "__main__":
    main()
