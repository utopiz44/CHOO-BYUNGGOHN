"""
3단계: PPO (RLHF)
SFT 모델을 actor로, RM을 reward로 사용해 정책을 강화학습으로 튜닝.
TRL의 고전(classic) PPOTrainer.step() 루프를 사용한다 — StackLLaMA /
KoChatGPT 튜토리얼과 동일한 방식.

주의: TRL은 버전에 따라 PPOTrainer 시그니처가 크게 바뀐다.
이 코드는 trl==0.7.x ~ 0.8.x 계열(step 루프 API) 기준.
    pip install "trl==0.8.6" "transformers>=4.38,<4.42"
newer TRL(0.11+)을 쓴다면 PPOTrainer(args, model, ref_model, reward_model,
value_model, train_dataset=...) 형태로 바꿔야 한다.

입력: 프롬프트 JSON list [{"prompt":...}, ...]
출력: ./ckpt/ppo/

사용 예:
    python train_ppo.py --prompts data/ppo_prompts.json \
        --sft ./ckpt/sft --rm ./ckpt/rm --out ./ckpt/ppo
"""
import argparse
import json
import torch
from tqdm import tqdm
from transformers import GPT2ForSequenceClassification
from trl import (PPOTrainer, PPOConfig, AutoModelForCausalLMWithValueHead)
from trl.core import LengthSampler
from utils import load_tokenizer, build_prompt


def load_prompts(path):
    with open(path, encoding="utf-8") as f:
        rows = json.load(f)
    return [r["prompt"] for r in rows]


@torch.no_grad()
def rm_scores(rm, tokenizer, texts, device):
    enc = tokenizer(texts, return_tensors="pt", padding=True,
                    truncation=True, max_length=512).to(device)
    return rm(**enc).logits.squeeze(-1)  # (batch,)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompts", required=True)
    ap.add_argument("--sft", default="./ckpt/sft")
    ap.add_argument("--rm", default="./ckpt/rm")
    ap.add_argument("--out", default="./ckpt/ppo")
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--bs", type=int, default=8)
    args = ap.parse_args()

    device = "cuda"
    tokenizer = load_tokenizer()

    # actor(+value head)와 참조모델(ref)은 SFT 체크포인트에서 시작
    model = AutoModelForCausalLMWithValueHead.from_pretrained(args.sft).to(device)
    ref_model = AutoModelForCausalLMWithValueHead.from_pretrained(args.sft).to(device)
    # reward model
    rm = GPT2ForSequenceClassification.from_pretrained(args.rm, num_labels=1).to(device)
    rm.config.pad_token_id = tokenizer.pad_token_id
    rm.eval()

    config = PPOConfig(batch_size=args.bs, mini_batch_size=args.bs,
                       learning_rate=1.41e-5, log_with=None)
    ppo = PPOTrainer(config, model, ref_model, tokenizer)

    prompts = load_prompts(args.prompts)
    gen_len = LengthSampler(32, 128)
    gen_kwargs = dict(min_length=-1, top_k=50, top_p=0.9, do_sample=True,
                      pad_token_id=tokenizer.pad_token_id,
                      eos_token_id=tokenizer.eos_token_id)

    idx = 0
    for step in tqdm(range(args.steps), desc="PPO"):
        # 배치 프롬프트 샘플
        batch_prompts = [prompts[(idx + i) % len(prompts)] for i in range(args.bs)]
        idx += args.bs
        query_tensors = [tokenizer(build_prompt(p), return_tensors="pt").input_ids[0].to(device)
                         for p in batch_prompts]

        # 응답 생성
        response_tensors = []
        for q in query_tensors:
            gen_kwargs["max_new_tokens"] = gen_len()
            resp = ppo.generate(q, **gen_kwargs)
            response_tensors.append(resp.squeeze()[q.shape[0]:])

        responses = [tokenizer.decode(r, skip_special_tokens=True) for r in response_tensors]

        # RM으로 보상 계산 (프롬프트+응답 전체를 스코어링)
        full_texts = [build_prompt(p) + r for p, r in zip(batch_prompts, responses)]
        scores = rm_scores(rm, tokenizer, full_texts, device)
        rewards = [s for s in scores]  # PPOTrainer는 텐서 리스트를 기대

        # PPO 업데이트
        stats = ppo.step(query_tensors, response_tensors, rewards)
        if step % 20 == 0:
            print(f"step {step} | mean_reward={scores.mean().item():.3f}")

    ppo.save_pretrained(args.out)
    tokenizer.save_pretrained(args.out)
    print(f"[PPO] 저장 완료 → {args.out}")


if __name__ == "__main__":
    main()
