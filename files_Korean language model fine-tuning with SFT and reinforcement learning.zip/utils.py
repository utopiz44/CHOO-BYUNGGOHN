"""
공통 유틸리티: KoGPT2 토크나이저/모델 로더, 프롬프트 포맷, 생성 헬퍼.
SFT / RM / PPO / 평가 스크립트에서 모두 재사용한다.
"""
import torch
from transformers import PreTrainedTokenizerFast, GPT2LMHeadModel

BASE_MODEL = "skt/kogpt2-base-v2"

# KoChatGPT 계열 표준 프롬프트 포맷. 세 단계 모두 동일 포맷을 써야
# 분포가 어긋나지 않는다(특히 PPO에서 SFT 모델을 actor로 쓰므로 필수).
PROMPT_TEMPLATE = "### 질문:\n{instruction}\n\n### 답변:\n"


def load_tokenizer():
    # KoGPT2는 bos=eos='</s>'. pad 토큰을 반드시 지정해야 배치 학습이 가능.
    tok = PreTrainedTokenizerFast.from_pretrained(
        BASE_MODEL,
        bos_token="</s>", eos_token="</s>", unk_token="<unk>",
        pad_token="<pad>", mask_token="<mask>",
    )
    return tok


def load_lm(path=BASE_MODEL, device="cuda"):
    model = GPT2LMHeadModel.from_pretrained(path)
    model.to(device)
    return model


def build_prompt(instruction: str) -> str:
    return PROMPT_TEMPLATE.format(instruction=instruction.strip())


@torch.no_grad()
def generate(model, tokenizer, instruction: str, device="cuda", **gen_kwargs):
    """instruction 하나에 대한 응답 문자열을 반환. gen_kwargs로 디코딩 전략 주입."""
    prompt = build_prompt(instruction)
    ids = tokenizer(prompt, return_tensors="pt").to(device)
    defaults = dict(
        max_new_tokens=128,
        pad_token_id=tokenizer.pad_token_id,
        eos_token_id=tokenizer.eos_token_id,
        no_repeat_ngram_size=2,
    )
    defaults.update(gen_kwargs)
    out = model.generate(**ids, **defaults)
    # 프롬프트 길이만큼 잘라내 응답만 반환
    gen = out[0][ids["input_ids"].shape[1]:]
    return tokenizer.decode(gen, skip_special_tokens=True).strip()


# 루브릭 ①: 재학습 없이 SFT 모델 품질을 끌어올리는 디코딩 전략 모음
DECODING_VARIANTS = {
    "greedy": dict(do_sample=False),
    "beam4":  dict(num_beams=4, do_sample=False, early_stopping=True),
    "topk":   dict(do_sample=True, top_k=50, temperature=0.8),
    "topp":   dict(do_sample=True, top_p=0.9, temperature=0.8),
}
