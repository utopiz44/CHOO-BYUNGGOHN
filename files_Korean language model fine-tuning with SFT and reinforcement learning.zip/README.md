# KoGPT2 RLHF (SFT → RM → PPO)

KoGPT2(`skt/kogpt2-base-v2`)를 base로 SFT / Reward Model / PPO를 순서대로 학습하고,
루브릭 ①②③을 충족하는 분석 산출물을 생성하는 최소 스캐폴드.

## 루브릭 매핑

| 루브릭 | 어디서 충족되나 |
|---|---|
| ① 데이터 정제 / 성능 향상 | `data/prepare_data.py`(정제 리포트) + `evaluate.py`의 `decoding.csv`(Beam/Top-k/Top-p 비교) |
| ② SFT vs RM 결과 분석 | `evaluate.py` → `report.md`의 RM 평균점수·win-rate |
| ③ 기존 KoGPT2 vs SFT | `evaluate.py` → `report.md`의 perplexity 비교 + 정성 샘플표 |

## 데이터 포맷

- SFT: `[{"prompt": "...", "completion": "..."}, ...]`
- RM : `[{"prompt": "...", "chosen": "...", "rejected": "..."}, ...]`
- PPO: `[{"prompt": "..."}, ...]`
- 평가 프롬프트: `[{"prompt": "..."}, ...]`
- (선택) perplexity용 val: `[{"text": "..."}]` 또는 `[{"prompt":..,"completion":..}]`

## 실행 순서

```bash
pip install -r requirements.txt

# ① 데이터 정제
python data/prepare_data.py --in raw_sft.json --out data/sft_clean.json

# 1단계 SFT
python train_sft.py --data data/sft_clean.json --out ./ckpt/sft

# 2단계 RM
python train_rm.py --data data/rm_pairs.json --out ./ckpt/rm

# 3단계 PPO
python train_ppo.py --prompts data/ppo_prompts.json \
    --sft ./ckpt/sft --rm ./ckpt/rm --out ./ckpt/ppo

# 분석 (②③ + 디코딩 ①)
python evaluate.py --base skt/kogpt2-base-v2 --sft ./ckpt/sft \
    --ppo ./ckpt/ppo --rm ./ckpt/rm \
    --prompts data/eval_prompts.json --valtext data/val.json
```

## 주의 / 대안

- **VRAM**: KoGPT2-base(125M) 기준 SFT/RM은 12GB급에서 가능. PPO는 actor+ref+RM을
  동시에 올리므로 여유가 더 필요하다. 부족하면 `--bs`를 낮추고 gradient_accumulation을 키운다.
- **TRL 버전**: `train_ppo.py`는 `trl==0.8.6`의 `PPOTrainer.step()` 루프 기준.
  최신 TRL(0.11+)은 시그니처가 달라 `PPOTrainer(args, model, ref_model, reward_model,
  value_model, train_dataset=...)` 형태로 수정해야 한다.
- **KoChatGPT(Coati) 프레임워크로 이미 학습 중이라면** train_*.py는 건너뛰고
  `evaluate.py`만 써도 된다 — 체크포인트 경로만 맞춰주면 프레임워크 무관하게 동작한다.
- **루브릭 ①에서 foundation model 교체를 택한다면** `utils.BASE_MODEL`을
  `skt/ko-gpt-trinity-1.2B-v0.5` 등으로 바꾸고, requirements의 peft/bitsandbytes 주석을
  해제해 LoRA/QLoRA로 메모리를 확보한다.
