"""
루브릭 ① '데이터셋 정제' 경로.
원본 instruction 데이터(JSON list: [{"prompt":..., "completion":...}, ...])를
정제해 SFT 학습용으로 저장한다. 정제 전/후 통계를 함께 출력해
"무엇을, 왜 걸렀는지"를 보고서에 쓸 수 있게 한다.

사용 예:
    python data/prepare_data.py --in raw_sft.json --out data/sft_clean.json
"""
import argparse
import json
import re

HANGUL = re.compile(r"[가-힣]")
MULTISPACE = re.compile(r"[ \t]+")
MULTINEWLINE = re.compile(r"\n{3,}")


def normalize(text: str) -> str:
    text = text.replace("\r\n", "\n").strip()
    text = MULTISPACE.sub(" ", text)
    text = MULTINEWLINE.sub("\n\n", text)
    return text


def is_korean_enough(text: str, min_ratio=0.3) -> bool:
    """한글 비율이 너무 낮은(영어/코드 위주) 샘플 제거용."""
    if not text:
        return False
    han = len(HANGUL.findall(text))
    return han / max(len(text), 1) >= min_ratio


def clean(records, min_len=5, max_len=1000):
    seen = set()
    kept, stats = [], {"dup": 0, "empty": 0, "too_short": 0, "too_long": 0, "non_ko": 0}
    for r in records:
        p = normalize(r.get("prompt", ""))
        c = normalize(r.get("completion", r.get("response", "")))
        if not p or not c:
            stats["empty"] += 1; continue
        if len(c) < min_len:
            stats["too_short"] += 1; continue
        if len(c) > max_len:
            stats["too_long"] += 1; continue
        if not is_korean_enough(c):
            stats["non_ko"] += 1; continue
        key = (p, c)
        if key in seen:
            stats["dup"] += 1; continue
        seen.add(key)
        kept.append({"prompt": p, "completion": c})
    return kept, stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    ap.add_argument("--min_len", type=int, default=5)
    ap.add_argument("--max_len", type=int, default=1000)
    args = ap.parse_args()

    with open(args.inp, encoding="utf-8") as f:
        raw = json.load(f)

    kept, stats = clean(raw, args.min_len, args.max_len)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(kept, f, ensure_ascii=False, indent=2)

    # 보고서에 그대로 붙일 수 있는 정제 리포트
    print(f"[정제 리포트] 원본 {len(raw)} → 정제 {len(kept)} "
          f"(제거 {len(raw) - len(kept)})")
    for k, v in stats.items():
        print(f"  - {k:10s}: {v}")


if __name__ == "__main__":
    main()
